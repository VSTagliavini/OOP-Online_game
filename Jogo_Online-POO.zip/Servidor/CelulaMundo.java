public class CelulaMundo extends Atomo {
}