public class Atomo {
    int ID;
    boolean Permeavel;
    void Interacao(Jogador Personagem) {}
}