public class Espada extends Item {
    Espada() {
        chave = 0;
        ID = 11;
    }
}