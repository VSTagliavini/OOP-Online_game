public class Entidade extends Atomo {
    public int Vida, Item, chave;
}