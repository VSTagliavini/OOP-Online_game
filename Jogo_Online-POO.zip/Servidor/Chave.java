public class Chave extends Item {
    Chave(int chave) {
        this.chave = chave;
        ID = 10;
    }   
}