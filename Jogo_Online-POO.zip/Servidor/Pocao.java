public class Pocao extends Item {
    Pocao(int chave) {
        this.chave = chave;
        ID = 12 + chave;
    }
}