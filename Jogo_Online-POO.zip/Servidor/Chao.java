public class Chao extends CelulaMundo {
    Chao() {
        Permeavel = true;
        ID = 9;
    }
}
