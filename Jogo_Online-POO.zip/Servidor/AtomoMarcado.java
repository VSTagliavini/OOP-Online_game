public class AtomoMarcado extends Atomo {
    AtomoMarcado() {
        ID = 0;
    }
}