public class Parede extends CelulaMundo {
    Parede() {
        Permeavel = false;
        ID = 12;
    }
}